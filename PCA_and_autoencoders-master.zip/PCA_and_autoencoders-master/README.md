# PCA and autoencoders

Principal component analysis (PCA) is an example of dimensionality reduction.

Autoencoders generalize the idea to non-linear transformations.

The interactive Jupyter notebook let's you train such autoencoders yourself, and see the results.
